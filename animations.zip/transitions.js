/* ═══════════════════════════════════════════
   RED ANACONDA — transitions.js
   made by azerkash
═══════════════════════════════════════════ */

// Override tab switch with smooth animation
window.switchTab = function(id, btn) {
  const current = document.querySelector('.tab-content.active');
  const next = document.getElementById('tab-' + id);

  if (current === next) return;

  // Animate out
  current.style.opacity = '0';
  current.style.transform = 'translateY(-8px)';
  current.style.transition = 'opacity 0.18s ease, transform 0.18s ease';

  setTimeout(() => {
    current.classList.remove('active');
    current.style.opacity = '';
    current.style.transform = '';
    current.style.transition = '';

    // Animate in
    next.classList.add('active');
    next.style.opacity = '0';
    next.style.transform = 'translateY(12px)';
    next.style.transition = 'opacity 0.25s ease, transform 0.25s ease';

    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        next.style.opacity = '1';
        next.style.transform = 'translateY(0)';
      });
    });

    setTimeout(() => {
      next.style.opacity = '';
      next.style.transform = '';
      next.style.transition = '';
    }, 280);

  }, 180);

  // Update active tab button
  document.querySelectorAll('.tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
};

// Animate result rows when injected into DOM
function observeResults() {
  const observer = new MutationObserver((mutations) => {
    mutations.forEach(mutation => {
      mutation.addedNodes.forEach(node => {
        if (node.nodeType !== 1) return;

        // Animate panels
        node.querySelectorAll && node.querySelectorAll('.panel').forEach((el, i) => {
          el.style.opacity = '0';
          el.style.transform = 'translateY(10px)';
          setTimeout(() => {
            el.style.transition = 'opacity 0.35s ease, transform 0.35s ease';
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
          }, i * 80);
        });

        // Animate stat boxes
        node.querySelectorAll && node.querySelectorAll('.stat-box').forEach((el, i) => {
          el.style.opacity = '0';
          el.style.transform = 'scale(0.88)';
          setTimeout(() => {
            el.style.transition = 'opacity 0.3s cubic-bezier(0.34,1.56,0.64,1), transform 0.3s cubic-bezier(0.34,1.56,0.64,1)';
            el.style.opacity = '1';
            el.style.transform = 'scale(1)';
          }, i * 70 + 50);
        });

        // Animate result rows
        node.querySelectorAll && node.querySelectorAll('.result-row').forEach((el, i) => {
          el.style.opacity = '0';
          el.style.transform = 'translateX(-8px)';
          setTimeout(() => {
            el.style.transition = 'opacity 0.25s ease, transform 0.25s ease';
            el.style.opacity = '1';
            el.style.transform = 'translateX(0)';
          }, i * 40 + 100);
        });

        // Animate result cards
        node.querySelectorAll && node.querySelectorAll('.result-card').forEach((el, i) => {
          el.style.opacity = '0';
          el.style.transform = 'translateY(8px)';
          setTimeout(() => {
            el.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
          }, i * 90 + 60);
        });
      });
    });
  });

  // Observe all result containers
  ['osint-results', 'ip-results', 'domain-results', 'phone-results', 'email-results'].forEach(id => {
    const el = document.getElementById(id);
    if (el) observer.observe(el, { childList: true, subtree: true });
  });
}

// Typing effect for output terminals
function typeOutput(el, lines, delay = 40) {
  el.innerHTML = '';
  let lineIndex = 0;
  let charIndex = 0;
  let current = '';

  function type() {
    if (lineIndex >= lines.length) return;
    const line = lines[lineIndex];
    if (charIndex < line.length) {
      current += line[charIndex];
      charIndex++;
      // Re-render safely
      el.innerHTML = el.innerHTML.replace(/<span[^>]*>[^<]*$/, '') + current;
      setTimeout(type, delay);
    } else {
      el.innerHTML += '\n';
      current = '';
      charIndex = 0;
      lineIndex++;
      setTimeout(type, delay * 3);
    }
  }
  type();
}

// Ripple effect on buttons
function addRipple(e) {
  const btn = e.currentTarget;
  const circle = document.createElement('span');
  const diameter = Math.max(btn.clientWidth, btn.clientHeight);
  const radius = diameter / 2;
  const rect = btn.getBoundingClientRect();
  circle.style.cssText = `
    width: ${diameter}px;
    height: ${diameter}px;
    left: ${e.clientX - rect.left - radius}px;
    top: ${e.clientY - rect.top - radius}px;
    position: absolute;
    border-radius: 50%;
    background: rgba(226,75,74,0.2);
    transform: scale(0);
    animation: ripple 0.5s linear;
    pointer-events: none;
  `;
  const style = document.createElement('style');
  style.textContent = '@keyframes ripple { to { transform: scale(3); opacity: 0; } }';
  document.head.appendChild(style);
  btn.style.position = 'relative';
  btn.style.overflow = 'hidden';
  btn.appendChild(circle);
  setTimeout(() => circle.remove(), 600);
}

// Init everything on load
document.addEventListener('DOMContentLoaded', () => {
  observeResults();

  // Add ripple to all buttons
  document.querySelectorAll('.btn').forEach(btn => {
    btn.addEventListener('click', addRipple);
  });

  // Stagger tab buttons entrance
  document.querySelectorAll('.tab').forEach((tab, i) => {
    tab.style.opacity = '0';
    tab.style.transform = 'translateY(-6px)';
    setTimeout(() => {
      tab.style.transition = 'opacity 0.3s ease, transform 0.3s ease, color 0.15s, border-color 0.15s';
      tab.style.opacity = '1';
      tab.style.transform = 'translateY(0)';
    }, i * 60 + 200);
  });
});
